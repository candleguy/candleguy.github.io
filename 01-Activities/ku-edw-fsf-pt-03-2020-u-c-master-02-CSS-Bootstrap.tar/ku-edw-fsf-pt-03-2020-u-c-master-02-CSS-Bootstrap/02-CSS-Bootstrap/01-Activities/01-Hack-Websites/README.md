### File

* *None*

### Instructions

* For the next 15 minutes, take a website that you commonly use (Amazon, Google, Huff Po, etc.) and heavily modify it using the Google Developer Tools.

* Be sure to at least modify:
  * Content (Change words)
  * Colors
  * Spacing
  * Etc.

* Slack out a screenshot to the class when you’re done.
