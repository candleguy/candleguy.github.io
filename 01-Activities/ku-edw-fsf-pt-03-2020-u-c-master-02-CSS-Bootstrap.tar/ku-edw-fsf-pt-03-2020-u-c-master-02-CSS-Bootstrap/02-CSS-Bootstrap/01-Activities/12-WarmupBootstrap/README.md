### File

* *None*

### Instructions

* As a repeat of last class, quickly create an HTML web page.

* Then add in a Bootstrap component of your choosing.

* **HINT:** Copy the Bootstrap CSS link. Then copy the code from any Bootstrap element or CSS.
