### File

* *None*

### Instructions

* Working in pairs and using Bootstrap make a page that looks like the following image:

  ![Card-layout design](card-layout.png)

* Be sure to note the:
  * Grid Layout
  * Navbar
  * Sidebar card
  * Thumbnail
